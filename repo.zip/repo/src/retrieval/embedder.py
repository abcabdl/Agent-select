﻿from __future__ import annotations

import hashlib
from typing import List

import numpy as np


class BaseEmbedder:
    """Base embedder interface."""

    def __init__(self, dim: int):
        if dim <= 0:
            raise ValueError("dim must be positive")
        self.dim = dim

    def embed(self, texts: List[str]) -> np.ndarray:
        raise NotImplementedError


class DummyEmbedder(BaseEmbedder):
    """Deterministic embedder using a fixed seed."""

    def __init__(self, dim: int, seed: int = 7):
        super().__init__(dim)
        self.seed = int(seed)

    def embed(self, texts: List[str]) -> np.ndarray:
        vectors = np.zeros((len(texts), self.dim), dtype=np.float32)
        for idx, text in enumerate(texts):
            vectors[idx] = self._embed_one(text or "")
        return vectors

    def _embed_one(self, text: str) -> np.ndarray:
        digest = hashlib.sha256(text.encode("utf-8")).digest()
        mix = int.from_bytes(digest[:8], "little", signed=False)
        seed = (self.seed + mix) % (2**32)
        rng = np.random.default_rng(seed)
        return rng.standard_normal(self.dim).astype(np.float32)
