﻿from __future__ import annotations

from datetime import datetime
from typing import List

from core.cards import AgentCard
from core.registry import SQLiteRegistry


def _slug(value: str) -> str:
    cleaned = "".join(ch for ch in value.lower().strip().replace(" ", "-") if ch.isalnum() or ch == "-")
    return cleaned or "domain"


def _compose_embedding_text(
    role: str,
    domain: str,
    strengths: str,
    output_style: str,
    failure_modes: str,
    preferred_tools: List[str],
) -> str:
    tools = ", ".join(preferred_tools) if preferred_tools else "none"
    return (
        f"Role preference: {role}. "
        f"Domain: {domain}. "
        f"Strengths: {strengths}. "
        f"Output style: {output_style}. "
        f"Failure modes: {failure_modes}. "
        f"Preferred tools: {tools}."
    )


def generate_agents(
    domains: list[str],
    n_per_domain: int,
    roles: list[str],
    registry: SQLiteRegistry,
) -> List[AgentCard]:
    if not domains:
        raise ValueError("domains must be non-empty")
    if not roles:
        raise ValueError("roles must be non-empty")
    if n_per_domain <= 0:
        return []

    tool_ids = [card.id for card in registry.list({"kind": "tool"})]
    agents: List[AgentCard] = []
    role_count = len(roles)
    idx = 0

    for domain in domains:
        for i in range(n_per_domain):
            role = roles[idx % role_count]
            idx += 1
            output_style = "concise" if i % 2 == 0 else "detailed"
            strengths = "structured reasoning and data synthesis"
            failure_modes = "may overgeneralize or miss edge cases"
            preferred_tools = list(tool_ids)
            embedding_text = _compose_embedding_text(
                role,
                domain,
                strengths,
                output_style,
                failure_modes,
                preferred_tools,
            )
            agent_id = f"agent-{_slug(domain)}-{_slug(role)}-{i + 1}"
            name = f"{domain.title()} {role.title()} {i + 1}"
            description = (
                f"Role: {role}; Domain: {domain}; Output style: {output_style}. "
                f"Strengths: {strengths}. Failure modes: {failure_modes}. "
                f"Preferred tools: {', '.join(preferred_tools) if preferred_tools else 'none'}."
            )
            output_formats = ["json"] if output_style == "concise" else ["markdown"]
            agent = AgentCard(
                id=agent_id,
                name=name,
                kind="agent",
                version="1.0",
                updated_at=datetime.utcnow(),
                domain_tags=[domain],
                role_tags=[role],
                tool_tags=list(preferred_tools),
                modalities=["text"],
                output_formats=output_formats,
                permissions=["read"],
                cost_tier="low",
                latency_tier="medium",
                reliability_prior=0.75,
                description=description,
                examples=[f"Handle {domain} requests"],
                embedding_text=embedding_text,
                available_tool_ids=list(preferred_tools),
            )
            registry.register(agent)
            agents.append(agent)
    return agents
