﻿from __future__ import annotations

from datetime import datetime
from typing import Dict, Optional, Tuple

from core.cards import ToolCard
from core.registry import SQLiteRegistry


_TEXT_CLEANER_CODE = """import re


def run(inputs):
    text = inputs.get(\"text\", \"\")
    if not isinstance(text, str):
        return {\"error\": \"text must be a string\", \"text\": \"\"}
    cleaned = text.strip().lower()
    cleaned = re.sub(r\"[^\\w\\s]\", \"\", cleaned)
    cleaned = re.sub(r\"\\s+\", \" \", cleaned).strip()
    return {\"text\": cleaned}
"""

_BASIC_STATS_CODE = """def run(inputs):
    values = inputs.get(\"values\", [])
    if not isinstance(values, list):
        return {\"error\": \"values must be a list\", \"count\": 0}
    cleaned = [value for value in values if isinstance(value, (int, float))]
    if not cleaned:
        return {\"count\": 0, \"mean\": None, \"min\": None, \"max\": None}
    total = sum(cleaned)
    count = len(cleaned)
    return {\"count\": count, \"mean\": total / count, \"min\": min(cleaned), \"max\": max(cleaned)}
"""


class MockToolSynthesizer:
    """Rule-based mock tool synthesizer."""

    def __init__(self) -> None:
        self._templates = {
            "text_cleaner": {
                "code": _TEXT_CLEANER_CODE,
                "metadata": {
                    "description": "Normalize text by stripping, lowercasing, and removing punctuation.",
                    "domain_tags": ["text", "cleaning"],
                    "role_tags": ["utility"],
                    "tool_tags": ["text_cleaner"],
                    "modalities": ["text"],
                    "output_formats": ["json"],
                    "permissions": ["read"],
                    "cost_tier": "low",
                    "latency_tier": "low",
                    "reliability_prior": 0.8,
                    "examples": ["Clean a noisy string"],
                },
            },
            "basic_stats": {
                "code": _BASIC_STATS_CODE,
                "metadata": {
                    "description": "Compute basic statistics over a list of numbers.",
                    "domain_tags": ["analysis", "math"],
                    "role_tags": ["utility"],
                    "tool_tags": ["basic_stats"],
                    "modalities": ["text"],
                    "output_formats": ["json"],
                    "permissions": ["read"],
                    "cost_tier": "low",
                    "latency_tier": "low",
                    "reliability_prior": 0.85,
                    "examples": ["Compute mean/min/max"],
                },
            },
        }

    def synthesize(self, name: str) -> Tuple[str, Dict]:
        if name not in self._templates:
            raise ValueError(f"Unknown tool template: {name}")
        entry = self._templates[name]
        return entry["code"], entry["metadata"]


def register_tool(
    registry: SQLiteRegistry,
    tool_name: str,
    tool_id: Optional[str] = None,
    version: str = "1.0",
) -> ToolCard:
    synthesizer = MockToolSynthesizer()
    code, metadata = synthesizer.synthesize(tool_name)
    now = datetime.utcnow()

    card = ToolCard(
        id=tool_id or tool_name,
        name=tool_name,
        kind="tool",
        version=version,
        updated_at=now,
        domain_tags=metadata.get("domain_tags", []),
        role_tags=metadata.get("role_tags", []),
        tool_tags=metadata.get("tool_tags", []),
        modalities=metadata.get("modalities", []),
        output_formats=metadata.get("output_formats", []),
        permissions=metadata.get("permissions", []),
        cost_tier=metadata.get("cost_tier"),
        latency_tier=metadata.get("latency_tier"),
        reliability_prior=metadata.get("reliability_prior"),
        description=metadata.get("description", ""),
        examples=metadata.get("examples", []),
        embedding_text=metadata.get("description", tool_name),
    )

    registry.register(card)
    registry.register_tool_code(card.id, code, updated_at=now)
    return card
