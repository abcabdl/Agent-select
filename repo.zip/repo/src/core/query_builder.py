﻿from __future__ import annotations

from typing import Optional

from core.constraints import Constraints


def _constraints_text(constraints: Optional[Constraints]) -> str:
    if constraints is None:
        return ""
    pieces = []
    if constraints.domain_tags:
        pieces.append(f"Domain tags: {', '.join(constraints.domain_tags)}")
    if constraints.role_tags:
        pieces.append(f"Role tags: {', '.join(constraints.role_tags)}")
    if constraints.tool_tags:
        pieces.append(f"Tool tags: {', '.join(constraints.tool_tags)}")
    if constraints.modalities:
        pieces.append(f"Modalities: {', '.join(constraints.modalities)}")
    if constraints.output_formats:
        pieces.append(f"Output formats: {', '.join(constraints.output_formats)}")
    if constraints.permissions:
        pieces.append(f"Permissions: {', '.join(constraints.permissions)}")
    if constraints.cost_tier:
        pieces.append(f"Cost tier: {constraints.cost_tier}")
    if constraints.latency_tier:
        pieces.append(f"Latency tier: {constraints.latency_tier}")
    if constraints.reliability_prior is not None:
        pieces.append(f"Reliability prior >= {constraints.reliability_prior}")
    return " | ".join(pieces)


def build_role_query(task_text: str, role: str, constraints: Optional[Constraints] = None) -> str:
    role_key = role.strip().lower()
    constraints_text = _constraints_text(constraints)
    task_text = task_text.strip()

    if role_key == "planner":
        template = (
            "You are a planner. Break down the task into milestones, dependencies, and checkpoints. "
            "Focus on sequencing and feasibility. Task: {task}. {constraints}"
        )
    elif role_key == "researcher":
        template = (
            "You are a researcher. Gather evidence, compare sources, and note open questions. "
            "Focus on coverage and uncertainty. Task: {task}. {constraints}"
        )
    elif role_key == "builder":
        template = (
            "You are a builder. Implement the solution with clear inputs/outputs and practical steps. "
            "Focus on deliverables and integration. Task: {task}. {constraints}"
        )
    elif role_key == "checker":
        template = (
            "You are a checker. Validate outputs, test assumptions, and look for edge cases or failures. "
            "Focus on correctness and risk. Task: {task}. {constraints}"
        )
    else:
        template = "Role: {role}. Task: {task}. {constraints}"

    return template.format(task=task_text, role=role, constraints=constraints_text).strip()
