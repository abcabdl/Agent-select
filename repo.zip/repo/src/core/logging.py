﻿from __future__ import annotations

import json
import os
from datetime import datetime
from typing import Any, Dict, Optional


def write_event(
    task_id: str,
    workflow_version: str,
    role: str,
    selected_main: Optional[str],
    selected_shadow: Optional[str],
    candidates_topk: Any,
    output: Any,
    validation: Any,
    executor_result: Any,
    failure_type: Optional[str],
    action: Optional[str],
    runs_dir: str = "runs",
) -> str:
    os.makedirs(runs_dir, exist_ok=True)
    path = os.path.join(runs_dir, f"{task_id}.jsonl")
    record: Dict[str, Any] = {
        "timestamp": datetime.utcnow().isoformat(),
        "task_id": task_id,
        "workflow_version": workflow_version,
        "role": role,
        "selected_main": selected_main,
        "selected_shadow": selected_shadow,
        "candidates_topk": candidates_topk,
        "output": output,
        "validation": validation,
        "executor_result": executor_result,
        "failure_type": failure_type,
        "action": action,
    }
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=True) + "\n")
    return path
