﻿from __future__ import annotations

import multiprocessing as mp
import queue
from typing import Dict


_ALLOWED_MODULES = {"math", "re", "json", "datetime", "typing"}
_ORIGINAL_IMPORT = __import__


def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    root = name.split(".")[0]
    if root not in _ALLOWED_MODULES:
        raise ImportError(f"Import blocked: {name}")
    return _ORIGINAL_IMPORT(name, globals, locals, fromlist, level)


_SAFE_BUILTINS = {
    "__import__": _safe_import,
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "dict": dict,
    "enumerate": enumerate,
    "float": float,
    "int": int,
    "isinstance": isinstance,
    "len": len,
    "list": list,
    "max": max,
    "min": min,
    "print": print,
    "range": range,
    "set": set,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "zip": zip,
    "Exception": Exception,
    "ValueError": ValueError,
    "TypeError": TypeError,
    "KeyError": KeyError,
}


def _execute_tool_code(code: str, inputs: dict) -> Dict:
    sandbox_globals = {"__builtins__": _SAFE_BUILTINS}
    exec(code, sandbox_globals)
    run_fn = sandbox_globals.get("run")
    if run_fn is None or not callable(run_fn):
        raise ValueError("Tool code must define callable run(inputs)")
    output = run_fn(inputs)
    if not isinstance(output, dict):
        raise TypeError("Tool run(inputs) must return dict")
    return output


def _sandbox_worker(code: str, inputs: dict, result_queue: mp.Queue) -> None:
    try:
        output = _execute_tool_code(code, inputs)
        result_queue.put({"ok": True, "output": output, "error": None})
    except Exception as exc:
        result_queue.put(
            {
                "ok": False,
                "output": None,
                "error": {"code": type(exc).__name__, "message": str(exc)},
            }
        )


def execute_tool_code(code: str, inputs: dict, timeout_s: float = 1.0) -> Dict:
    result_queue: mp.Queue = mp.Queue()
    process = mp.Process(target=_sandbox_worker, args=(code, inputs, result_queue))
    process.start()
    process.join(timeout_s)

    if process.is_alive():
        process.terminate()
        process.join()
        return {
            "ok": False,
            "output": None,
            "error": {"code": "timeout", "message": f"Execution exceeded {timeout_s}s"},
        }

    try:
        return result_queue.get_nowait()
    except queue.Empty:
        return {
            "ok": False,
            "output": None,
            "error": {"code": "no_result", "message": "No result from sandbox"},
        }
