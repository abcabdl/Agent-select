﻿from __future__ import annotations

import argparse
import json
import os
from typing import Dict, List

from core.registry import SQLiteRegistry
from execution.orchestrator import run_workflow
from retrieval.embedder import DummyEmbedder
from retrieval.faiss_index import HNSWIndex


def _parse_roles(value: str) -> List[str]:
    value = value.strip()
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def _parse_constraints(value: str) -> Dict[str, Dict[str, object]]:
    if not value:
        return {}
    return json.loads(value)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run query through orchestrator")
    parser.add_argument("--query", required=True, type=str)
    parser.add_argument("--db", default="demo_registry.sqlite", type=str)
    parser.add_argument("--index_dir", default="index", type=str)
    parser.add_argument("--dim", default=64, type=int)
    parser.add_argument("--seed", default=7, type=int)
    parser.add_argument("--roles", default="planner,researcher,builder,checker", type=str)
    parser.add_argument("--constraints", default="", type=str, help="JSON string per role")
    parser.add_argument("--workflow_version", default="v1", type=str)
    parser.add_argument("--reranker_model", default="models/reranker.json", type=str)
    parser.add_argument("--bandit_db", default="models/bandit.sqlite", type=str)
    parser.add_argument("--top_n", default=20, type=int)
    parser.add_argument("--top_k", default=5, type=int)
    parser.add_argument("--rerank_top_m", default=3, type=int)
    parser.add_argument("--mmr_lambda", default=0.5, type=float)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    roles = _parse_roles(args.roles)
    constraints_per_role = _parse_constraints(args.constraints)
    index_path = os.path.join(args.index_dir, "faiss.index")

    index = HNSWIndex.load(index_path)
    embedder = DummyEmbedder(dim=args.dim, seed=args.seed)

    with SQLiteRegistry(args.db) as registry:
        result = run_workflow(
            task_text=args.query,
            roles=roles,
            constraints_per_role=constraints_per_role,
            workflow_version=args.workflow_version,
            registry=registry,
            index=index,
            embedder=embedder,
            top_n=args.top_n,
            top_k=args.top_k,
            rerank_top_m=args.rerank_top_m,
            mmr_lambda=args.mmr_lambda,
            reranker_model_path=args.reranker_model,
            bandit_db_path=args.bandit_db,
        )

    print(result.get("answer"))
    print("log_path:", result.get("log_path"))


if __name__ == "__main__":
    main()
