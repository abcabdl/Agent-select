﻿from __future__ import annotations

import os
import uuid
from typing import Any, Dict, List, Optional

from core.contracts import validate_output
from core.failure_router import route_failure
from core.logging import write_event
from core.query_builder import build_role_query
from execution.probe_commit import probe_commit
from retrieval.search_service import get_candidates
from routing.bandit_store import BanditStore
from routing.reranker_model import TfidfLinearReranker


class MockLLMClient:
    """Mock LLM client that returns structured outputs per role."""

    def generate(self, role: str, task_text: str, context: Dict[str, Any]) -> Dict[str, Any]:
        agent = context.get("agent", {})
        agent_name = agent.get("name") or agent.get("id") or "agent"
        agent_domain = ",".join(agent.get("domain_tags") or [])
        agent_tools = ",".join(agent.get("tool_tags") or [])
        role_key = role.strip().lower()
        if role_key == "planner":
            return {
                "steps": [
                    f"{agent_name} clarify scope for: {task_text}",
                    "Break down milestones",
                    "Sequence tasks with dependencies",
                ],
                "acceptance_criteria": [
                    "Plan covers core tasks",
                    f"Dependencies explicit for {agent_domain or 'general'}",
                ],
            }
        if role_key == "researcher":
            return {
                "search_queries": [f"{task_text} overview", f"{task_text} {agent_domain}"],
                "sources": ["internal_knowledge_base", "public_docs"],
                "evidence_points": [f"Findings summarized with {agent_tools or 'tools'}"],
            }
        if role_key == "builder":
            return {
                "runnable_plan": ["Implement core logic", "Wire dependencies", "Run tests"],
                "code_or_commands": f"run build; use {agent_tools or 'default tools'}",
                "self_test": ["unit tests pass", "smoke test pass"],
            }
        if role_key == "checker":
            return {
                "test_cases": ["happy path", "edge case"],
                "verdicts": ["pass", "needs review"],
                "failure_localization": f"review edge case for {agent_name}",
            }
        return {}

    def rewrite_format(self, role: str, output: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        return self.generate(role, "format_fix", context)

    def clarify(self, role: str, task_text: str) -> Dict[str, Any]:
        return {"clarifier": f"Provide missing details for {role} about {task_text}"}


def _build_candidate_texts(registry, candidates: List[Dict[str, Any]]) -> List[str]:
    texts: List[str] = []
    for candidate in candidates:
        card_id = candidate.get("card_id")
        if not card_id:
            texts.append("")
            continue
        card = registry.get(card_id)
        if card is None:
            texts.append("")
            continue
        texts.append(card.embedding_text or card.description or card.name)
    return texts


def _get_agent_context(registry, agent_id: Optional[str]) -> Dict[str, Any]:
    if not agent_id:
        return {"id": None, "name": None, "domain_tags": [], "tool_tags": []}
    card = registry.get(agent_id)
    if card is None:
        return {"id": agent_id, "name": None, "domain_tags": [], "tool_tags": []}
    return {
        "id": card.id,
        "name": card.name,
        "domain_tags": card.domain_tags,
        "role_tags": card.role_tags,
        "tool_tags": card.tool_tags,
        "description": card.description,
        "available_tool_ids": getattr(card, "available_tool_ids", []),
    }


def run_workflow(
    task_text: str,
    roles: Optional[List[str]] = None,
    constraints_per_role: Optional[Dict[str, Dict[str, Any]]] = None,
    workflow_version: str = "v1",
    registry=None,
    index=None,
    embedder=None,
    top_n: int = 20,
    top_k: int = 5,
    rerank_top_m: int = 3,
    mmr_lambda: float = 0.5,
    max_attempts: int = 3,
    bandit_db_path: Optional[str] = None,
    reranker_model_path: Optional[str] = None,
) -> Dict[str, Any]:
    if registry is None or index is None or embedder is None:
        raise ValueError("registry, index, embedder are required")

    role_list = roles or ["planner", "researcher", "builder", "checker"]
    constraints_per_role = constraints_per_role or {}
    task_id = uuid.uuid4().hex
    llm = MockLLMClient()
    if reranker_model_path and os.path.exists(reranker_model_path):
        reranker = TfidfLinearReranker.load(reranker_model_path)
    else:
        reranker = TfidfLinearReranker()
    results: Dict[str, Any] = {}
    log_path: Optional[str] = None
    selections: Dict[str, Dict[str, Any]] = {}

    for role in role_list:
        constraints = constraints_per_role.get(role)
        candidates = get_candidates(
            task_text=task_text,
            role=role,
            constraints=constraints,
            kind="agent",
            top_n=top_n,
            top_k=top_k,
            mmr_lambda=mmr_lambda,
            registry=registry,
            index=index,
            embedder=embedder,
        )

        if candidates:
            candidate_texts = _build_candidate_texts(registry, candidates)
            query_text = build_role_query(task_text, role, constraints)
            rerank_indices, _ = reranker.rank(query_text, candidate_texts, top_m=min(rerank_top_m, len(candidates)))
            reranked = [candidates[i] for i in rerank_indices]
        else:
            reranked = []

        probe_result = probe_commit(
            task_text=task_text,
            role=role,
            constraints=constraints,
            candidates=reranked,
            top_probe=min(5, len(reranked)),
            max_shadows=2,
        )
        selected_main = probe_result.get("selected_main")
        selected_shadows = probe_result.get("selected_shadows", [])
        if selected_main is None and reranked:
            selected_main = reranked[0]["card_id"]
        selected_shadow = selected_shadows[0] if selected_shadows else None
        selections[role] = {
            "main": selected_main,
            "shadows": selected_shadows,
        }

        attempt = 0
        role_context: Dict[str, Any] = {"upstream": results}
        agent_context = _get_agent_context(registry, selected_main)
        role_context["agent"] = agent_context
        while attempt < max_attempts:
            output = llm.generate(role, task_text, role_context)
            valid, errors, model = validate_output(role, output)
            validation = {"ok": valid, "errors": errors}
            executor_result = None
            failure_type = None
            action = None

            if valid:
                results[role] = model.model_dump()
                log_path = write_event(
                    task_id=task_id,
                    workflow_version=workflow_version,
                    role=role,
                    selected_main=selected_main,
                    selected_shadow=selected_shadow,
                    candidates_topk=reranked,
                    output=output,
                    validation=validation,
                    executor_result=executor_result,
                    failure_type=failure_type,
                    action=action,
                )
                break

            route = route_failure(role, output, errors, executor_result)
            failure_type = route["failure_type"]
            action = route["action"]

            if failure_type == "A_contract":
                repaired = llm.rewrite_format(role, output, role_context)
                valid_fix, errors_fix, model_fix = validate_output(role, repaired)
                validation = {"ok": valid_fix, "errors": errors_fix}
                if valid_fix:
                    results[role] = model_fix.model_dump()
                    log_path = write_event(
                        task_id=task_id,
                        workflow_version=workflow_version,
                        role=role,
                        selected_main=selected_main,
                        selected_shadow=selected_shadow,
                        candidates_topk=reranked,
                        output=repaired,
                        validation=validation,
                        executor_result=executor_result,
                        failure_type=failure_type,
                        action=action,
                    )
                    break
                log_path = write_event(
                    task_id=task_id,
                    workflow_version=workflow_version,
                    role=role,
                    selected_main=selected_main,
                    selected_shadow=selected_shadow,
                    candidates_topk=reranked,
                    output=repaired,
                    validation=validation,
                    executor_result=executor_result,
                    failure_type=failure_type,
                    action=action,
                )
                attempt += 1
                continue

            if failure_type == "B_missing_info":
                role_context.update(llm.clarify(role, task_text))
                log_path = write_event(
                    task_id=task_id,
                    workflow_version=workflow_version,
                    role=role,
                    selected_main=selected_main,
                    selected_shadow=selected_shadow,
                    candidates_topk=reranked,
                    output=output,
                    validation=validation,
                    executor_result=executor_result,
                    failure_type=failure_type,
                    action=action,
                )
                attempt += 1
                continue

            if failure_type == "C_capability":
                log_path = write_event(
                    task_id=task_id,
                    workflow_version=workflow_version,
                    role=role,
                    selected_main=selected_main,
                    selected_shadow=selected_shadow,
                    candidates_topk=reranked,
                    output=output,
                    validation=validation,
                    executor_result=executor_result,
                    failure_type=failure_type,
                    action=action,
                )
                if selected_shadow and selected_shadow != selected_main:
                    selected_main = selected_shadow
                    selected_shadow = None
                    agent_context = _get_agent_context(registry, selected_main)
                    role_context["agent"] = agent_context
                    attempt += 1
                    continue
                break

            attempt += 1

        if role not in results:
            results[role] = {"error": "no_valid_output"}

    checker_ok = True
    checker_output = results.get("checker")
    if isinstance(checker_output, dict) and checker_output.get("error"):
        checker_ok = False

    if bandit_db_path:
        with BanditStore(bandit_db_path) as store:
            for role, selection in selections.items():
                main_id = selection.get("main")
                shadow_ids = selection.get("shadows", [])
                if main_id:
                    store.update(workflow_version, role, main_id, reward=1.0 if checker_ok else 0.0, confidence=1.0)
                for shadow_id in shadow_ids:
                    store.update(workflow_version, role, shadow_id, reward=1.0 if checker_ok else 0.0, confidence=0.5)

    answer_lines = []
    for role in role_list:
        answer_lines.append(f"[{role}] {results.get(role)}")
    answer = "\n".join(answer_lines)

    return {
        "task_id": task_id,
        "answer": answer,
        "log_path": log_path,
        "results": results,
    }
