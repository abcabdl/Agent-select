﻿from __future__ import annotations

import os

from core.registry import SQLiteRegistry
from execution.orchestrator import run_workflow
from generation.agent_generator import generate_agents
from generation.tool_generator import register_tool
from retrieval.build_index import build_index
from retrieval.embedder import DummyEmbedder


def run_demo(
    task_text: str = "Summarize quarterly performance and risks",
    db_path: str = "demo_registry.sqlite",
    index_dir: str = "./index",
    tool_count: int = 20,
    domains: list[str] | None = None,
    n_per_domain: int = 40,
    roles: list[str] | None = None,
    dim: int = 64,
    seed: int = 7,
    workflow_version: str = "v1",
) -> dict:
    domains = domains or ["finance", "health", "tech", "retail", "ops"]
    roles = roles or ["planner", "researcher", "builder", "checker"]

    if os.path.exists(db_path):
        os.remove(db_path)

    with SQLiteRegistry(db_path) as registry:
        for i in range(tool_count):
            tool_name = "text_cleaner" if i % 2 == 0 else "basic_stats"
            register_tool(registry, tool_name, tool_id=f"{tool_name}-{i}")
        generate_agents(domains=domains, n_per_domain=n_per_domain, roles=roles, registry=registry)

    index = build_index(db_path=db_path, kind="agent", out_dir=index_dir, dim=dim, seed=seed)
    embedder = DummyEmbedder(dim=dim, seed=seed)

    registry = SQLiteRegistry(db_path)
    try:
        result = run_workflow(
            task_text=task_text,
            roles=roles,
            constraints_per_role={},
            workflow_version=workflow_version,
            registry=registry,
            index=index,
            embedder=embedder,
            top_n=10,
            top_k=5,
            mmr_lambda=0.5,
        )
    finally:
        registry.close()

    return result


def main() -> None:
    result = run_demo()
    print(result.get("answer"))
    print(f"log_path: {result.get('log_path')}")


if __name__ == "__main__":
    main()
