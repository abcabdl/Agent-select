﻿# Agent-router

This repo provides a minimal agent routing stack with registry, retrieval, reranking, and orchestration.

## Create a virtual environment

PowerShell:

```
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

bash:

```
python -m venv .venv
source .venv/bin/activate
```

## Install dependencies

```
python -m pip install -r requirements.txt --progress-bar off
```

## End-to-end flow: generate agents → train reranker → query & execute

All commands assume you are in `Agent-router/repo`.

### 1) Generate tools/agents + build index + run demo (writes runs/<task_id>.jsonl)

```
python -m src.execution.demo_runner
```

Optional custom demo parameters:

```
@'
from execution.demo_runner import run_demo
result = run_demo(
    task_text="生成样例数据用于训练",
    db_path="demo_registry.sqlite",
    index_dir="index",
    tool_count=20,
    domains=["finance","health","tech","ops"],
    n_per_domain=50,
    roles=["planner","researcher","builder","checker"],
    dim=64,
    seed=7,
    workflow_version="v1",
)
print(result["log_path"])
'@ | python -
```

### 2) Export training data from runs

```
New-Item -ItemType Directory -Force data,models | Out-Null

python -m src.routing.export_training_data `
  --runs runs `
  --db demo_registry.sqlite `
  --out data/train.jsonl
```

### 3) Train reranker

```
python -m src.routing.train_router `
  --data data/train.jsonl `
  --out models/reranker.json `
  --epochs 5 `
  --lr 0.1
```

### 4) Query → match agents + collaboration mode → execute workflow

```
@'
import os
from core.registry import SQLiteRegistry
from retrieval.faiss_index import HNSWIndex
from retrieval.embedder import DummyEmbedder
from execution.orchestrator import run_workflow

db_path = "demo_registry.sqlite"
index_path = os.path.join("index","faiss.index")

index = HNSWIndex.load(index_path)
embedder = DummyEmbedder(dim=64, seed=7)

with SQLiteRegistry(db_path) as registry:
    result = run_workflow(
        task_text="请分析公司季度经营风险，并给出可执行建议",
        roles=["planner","researcher","builder","checker"],
        constraints_per_role={
            "researcher": {"domain_tags": ["finance"]},
            "builder": {"tool_tags": ["basic_stats"]},
        },
        workflow_version="v1",
        registry=registry,
        index=index,
        embedder=embedder,
        top_n=20,
        top_k=5,
        rerank_top_m=3,
        mmr_lambda=0.5,
        reranker_model_path="models/reranker.json",
        bandit_db_path="models/bandit.sqlite",
    )

print(result["answer"])
print("log_path:", result["log_path"])
'@ | python -
```

### Rebuild index after adding/updating agents

```
python -m src.retrieval.build_index --db demo_registry.sqlite --kind agent --out index --dim 64
```

### 5) Direct CLI: run a single query

```
python -m src.execution.run_query --query "请分析公司季度经营风险，并给出可执行建议"
```

Optional flags (examples):

```
python -m src.execution.run_query `
  --query "分析财务风险" `
  --db demo_registry.sqlite `
  --index_dir index `
  --roles "planner,researcher,builder,checker" `
  --constraints "{\"researcher\":{\"domain_tags\":[\"finance\"]}}" `
  --reranker_model models/reranker.json `
  --bandit_db models/bandit.sqlite
```

