﻿"""Core package."""
