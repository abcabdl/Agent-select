﻿"""Root package for the agent router project."""
