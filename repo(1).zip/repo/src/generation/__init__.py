﻿"""Generation package."""
