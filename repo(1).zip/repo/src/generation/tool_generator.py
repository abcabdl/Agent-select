﻿from __future__ import annotations

import os
import re
from datetime import datetime
from typing import Any, Dict, Optional, Tuple

from core.cards import ToolCard
from core.registry import SQLiteRegistry
from generation.llm_client import LLMClient


_TEXT_CLEANER_CODE = """import re


def run(inputs):
    text = inputs.get(\"text\", \"\")
    if not isinstance(text, str):
        return {\"error\": \"text must be a string\", \"text\": \"\"}
    cleaned = text.strip().lower()
    cleaned = re.sub(r\"[^\\w\\s]\", \"\", cleaned)
    cleaned = re.sub(r\"\\s+\", \" \", cleaned).strip()
    return {\"text\": cleaned}
"""

_BASIC_STATS_CODE = """def run(inputs):
    values = inputs.get(\"values\", [])
    if not isinstance(values, list):
        return {\"error\": \"values must be a list\", \"count\": 0}
    cleaned = [value for value in values if isinstance(value, (int, float))]
    if not cleaned:
        return {\"count\": 0, \"mean\": None, \"min\": None, \"max\": None}
    total = sum(cleaned)
    count = len(cleaned)
    return {\"count\": count, \"mean\": total / count, \"min\": min(cleaned), \"max\": max(cleaned)}
"""


class MockToolSynthesizer:
    """Rule-based mock tool synthesizer."""

    def __init__(self) -> None:
        self._templates = {
            "text_cleaner": {
                "code": _TEXT_CLEANER_CODE,
                "metadata": {
                    "description": "Normalize text by stripping, lowercasing, and removing punctuation.",
                    "domain_tags": ["text", "cleaning"],
                    "role_tags": ["utility"],
                    "tool_tags": ["text_cleaner"],
                    "modalities": ["text"],
                    "output_formats": ["json"],
                    "permissions": ["read"],
                    "cost_tier": "low",
                    "latency_tier": "low",
                    "reliability_prior": 0.8,
                    "examples": ["Clean a noisy string"],
                },
            },
            "basic_stats": {
                "code": _BASIC_STATS_CODE,
                "metadata": {
                    "description": "Compute basic statistics over a list of numbers.",
                    "domain_tags": ["analysis", "math"],
                    "role_tags": ["utility"],
                    "tool_tags": ["basic_stats"],
                    "modalities": ["text"],
                    "output_formats": ["json"],
                    "permissions": ["read"],
                    "cost_tier": "low",
                    "latency_tier": "low",
                    "reliability_prior": 0.85,
                    "examples": ["Compute mean/min/max"],
                },
            },
        }

    def synthesize(self, name: str) -> Tuple[str, Dict]:
        if name not in self._templates:
            raise ValueError(f"Unknown tool template: {name}")
        entry = self._templates[name]
        return entry["code"], entry["metadata"]


_CODE_BLOCK_RE = re.compile(r"```(?:python|py)?\s*(.*?)```", re.DOTALL)


def _extract_code(text: str) -> str:
    if not text:
        return ""
    match = _CODE_BLOCK_RE.search(text)
    if match:
        return match.group(1).strip()
    return text.strip()


def generate_tool_code(spec: Dict[str, Any], llm: LLMClient) -> str:
    name = spec.get("name", "Tool")
    description = spec.get("description", "")
    requirements = spec.get("requirements", "")
    inputs = ", ".join(spec.get("inputs") or [])
    outputs = ", ".join(spec.get("outputs") or [])
    system_msg = (
        "You are an expert Python developer. "
        "Return ONLY executable Python code, no markdown."
    )
    user_msg = f"""
Write a single Python module for this tool.

Tool Name: {name}
Description: {description}
Requirements: {requirements}
Inputs: {inputs}
Outputs: {outputs}

Guidelines:
1) The module MUST define a top-level function: run(inputs: dict) -> dict
2) Read parameters from inputs.get(...); use inputs.get("query") as fallback.
3) Return a dict. On failure, return {{"error": "...", "ok": False}}.
4) Use robust error handling. Keep code minimal and deterministic.
5) Only use standard library unless Requirements mention extra libs (e.g. httpx).
6) If calling external APIs, read API keys from environment variables (os.getenv).
7) Ensure the code is executable as-is.
"""
    response = llm.chat(
        [{"role": "system", "content": system_msg}, {"role": "user", "content": user_msg}],
        temperature=0.2,
        max_tokens=1400,
    )
    code = _extract_code(response)
    if "def run" not in code:
        raise ValueError("Generated tool code missing run(inputs) function")
    return code


def _slug(value: str) -> str:
    cleaned = "".join(ch for ch in value.lower().strip().replace(" ", "-") if ch.isalnum() or ch == "-")
    return cleaned or "tool"


def register_tool_from_spec(
    registry: SQLiteRegistry,
    spec: Dict[str, Any],
    code: str,
    tool_id: Optional[str] = None,
    version: str = "1.0",
    save_dir: Optional[str] = None,
) -> ToolCard:
    now = datetime.utcnow()
    name = str(spec.get("name") or tool_id or "tool")
    description = str(spec.get("description") or "")
    requirements = str(spec.get("requirements") or "")
    if requirements:
        description = f"{description} Requirements: {requirements}".strip()

    card = ToolCard(
        id=tool_id or _slug(name),
        name=name,
        kind="tool",
        version=version,
        updated_at=now,
        domain_tags=list(spec.get("domain_tags") or []),
        role_tags=list(spec.get("role_tags") or []),
        tool_tags=list(spec.get("tool_tags") or [name.lower()]),
        modalities=list(spec.get("modalities") or ["text"]),
        output_formats=list(spec.get("output_formats") or ["json"]),
        permissions=list(spec.get("permissions") or ["read"]),
        cost_tier=spec.get("cost_tier") or "medium",
        latency_tier=spec.get("latency_tier") or "medium",
        reliability_prior=spec.get("reliability_prior") or 0.7,
        description=description,
        examples=list(spec.get("examples") or []),
        embedding_text=spec.get("embedding_text") or description or name,
    )

    registry.register(card)
    registry.register_tool_code(card.id, code, updated_at=now)

    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
        path = os.path.join(save_dir, f"{card.id}.py")
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)
    return card


def register_tool(
    registry: SQLiteRegistry,
    tool_name: str,
    tool_id: Optional[str] = None,
    version: str = "1.0",
) -> ToolCard:
    synthesizer = MockToolSynthesizer()
    code, metadata = synthesizer.synthesize(tool_name)
    now = datetime.utcnow()

    card = ToolCard(
        id=tool_id or tool_name,
        name=tool_name,
        kind="tool",
        version=version,
        updated_at=now,
        domain_tags=metadata.get("domain_tags", []),
        role_tags=metadata.get("role_tags", []),
        tool_tags=metadata.get("tool_tags", []),
        modalities=metadata.get("modalities", []),
        output_formats=metadata.get("output_formats", []),
        permissions=metadata.get("permissions", []),
        cost_tier=metadata.get("cost_tier"),
        latency_tier=metadata.get("latency_tier"),
        reliability_prior=metadata.get("reliability_prior"),
        description=metadata.get("description", ""),
        examples=metadata.get("examples", []),
        embedding_text=metadata.get("description", tool_name),
    )

    registry.register(card)
    registry.register_tool_code(card.id, code, updated_at=now)
    return card
