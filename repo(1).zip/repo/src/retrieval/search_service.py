﻿from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from fastapi import FastAPI
from pydantic import BaseModel, Field

from core.constraints import Constraints, filter_candidates
from core.query_builder import build_role_query
from core.registry import SQLiteRegistry
from retrieval.embedder import BaseEmbedder, DummyEmbedder
from retrieval.faiss_index import HNSWIndex
from retrieval.mmr import mmr_rerank
from retrieval.build_index import build_index


class CandidateRequest(BaseModel):
    task_text: str
    role: str
    constraints: Optional[Dict[str, Any]] = None
    kind: str = Field(default="agent")
    top_n: int = Field(default=50, ge=1)
    top_k: int = Field(default=10, ge=1)
    mmr_lambda: float = Field(default=0.5)


class CandidateResponse(BaseModel):
    card_id: str
    score: float
    brief_tags: Dict[str, Any]


def _brief_tags(card) -> Dict[str, Any]:
    return {
        "domain_tags": card.domain_tags,
        "role_tags": card.role_tags,
        "tool_tags": card.tool_tags,
        "modalities": card.modalities,
        "output_formats": card.output_formats,
    }


def get_candidates(
    task_text: str,
    role: str,
    constraints: Optional[Dict[str, Any]],
    kind: str,
    top_n: int,
    top_k: int,
    mmr_lambda: float,
    registry: SQLiteRegistry,
    index: HNSWIndex,
    embedder: BaseEmbedder,
) -> List[Dict[str, Any]]:
    constraints_obj = Constraints(**constraints) if constraints else None
    query_text = build_role_query(task_text, role, constraints_obj)
    query_vec = embedder.embed([query_text])

    scores, id_rows = index.search(query_vec, top_k=top_n)
    ids = id_rows[0]
    score_row = scores[0]

    candidates_list = []
    with SQLiteRegistry(registry.db_path) as local_registry:
        for idx, card_id in enumerate(ids):
            if card_id is None:
                continue
            card = local_registry.get(card_id)
            if card is None:
                continue
            if card.kind != kind:
                continue
            candidates_list.append((card, float(score_row[idx])))

    filtered_cards = [card for card, _ in candidates_list]
    if constraints_obj is not None:
        filtered_cards = filter_candidates(filtered_cards, constraints_obj)

    if not filtered_cards:
        return []

    score_map = {card.id: score for card, score in candidates_list}
    candidate_texts = [card.embedding_text or card.description for card in filtered_cards]
    candidate_vecs = embedder.embed(candidate_texts)

    selected_indices, selected_scores = mmr_rerank(
        query_vec[0],
        candidate_vecs,
        lambda_param=mmr_lambda,
        top_k=top_k,
    )

    responses: List[Dict[str, Any]] = []
    for rank_idx, candidate_idx in enumerate(selected_indices):
        card = filtered_cards[candidate_idx]
        score = score_map.get(card.id, float(selected_scores[rank_idx]))
        responses.append(
            {
                "card_id": card.id,
                "score": score,
                "brief_tags": _brief_tags(card),
            }
        )
    return responses


def create_app(
    registry: SQLiteRegistry,
    index: HNSWIndex,
    embedder: BaseEmbedder,
) -> FastAPI:
    app = FastAPI()

    @app.post("/candidates", response_model=List[CandidateResponse])
    def candidates(request: CandidateRequest) -> List[CandidateResponse]:
        payload = get_candidates(
            task_text=request.task_text,
            role=request.role,
            constraints=request.constraints,
            kind=request.kind,
            top_n=request.top_n,
            top_k=request.top_k,
            mmr_lambda=request.mmr_lambda,
            registry=registry,
            index=index,
            embedder=embedder,
        )
        return [CandidateResponse(**item) for item in payload]

    return app


def _build_default_app() -> FastAPI:
    try:
        db_path = os.getenv("SEARCH_DB", "registry.sqlite")
        index_dir = os.getenv("SEARCH_INDEX_DIR", "./index")
        dim = int(os.getenv("SEARCH_DIM", "256"))
        seed = int(os.getenv("SEARCH_SEED", "7"))

        index_path = os.path.join(index_dir, "faiss.index")

        registry = SQLiteRegistry(db_path)
        if os.path.exists(index_path):
            index = HNSWIndex.load(index_path)
        else:
            index = build_index(db_path=db_path, kind="agent", out_dir=index_dir, dim=dim, seed=seed)
        embedder = DummyEmbedder(dim=dim, seed=seed)
        return create_app(registry=registry, index=index, embedder=embedder)
    except Exception:
        app = FastAPI()

        @app.get("/health")
        def health() -> Dict[str, Any]:
            return {"ok": False}

        return app


app = _build_default_app()
