﻿from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Ensure `core`, `generation`, etc. are importable when running as a module or script.
SRC_DIR = Path(__file__).resolve().parents[1]
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from core.registry import SQLiteRegistry
from execution.orchestrator import run_workflow
from generation.agent_generator import generate_agents, generate_agents_from_themes
from generation.llm_client import LLMClient
from generation.tool_generator import generate_tool_code, register_tool, register_tool_from_spec
from generation.tool_planner import plan_agent_themes, plan_tools_for_theme, themes_from_domains
from retrieval.build_index import build_index
from retrieval.embedder import DummyEmbedder

DEFAULT_DOMAINS = [
    "File System & IO",
    "Text Processing & Regex",
    "Data Analysis & Transformation (Pandas/Numpy)",
    "Web Utils & Scraping",
    "Network & Connectivity",
    "System Information & Process Management",
    "Image Processing (Pillow/OpenCV)",
    "Cryptography, Hashing & Security",
    "Date, Time & Scheduling",
    "Format Conversion (JSON/XML/YAML)",
    "Developer Utilities (Git/Code Analysis)",
    "Code Generation & Refactoring",
    "Code Review & Testing",
    "Mathematics & Scientific Calc",
    "Math & Problem Solving",
    "Commonsense & QA",
    "Knowledge & Reasoning",
    "Planning & Task Decomposition",
    "Archiving & Compression",
    "Multimedia (Audio/Video Metadata)",
    "Office Automation (PDF/Excel)",
]


def run_demo(
    task_text: str = "Summarize quarterly performance and risks",
    db_path: str = "demo_registry.sqlite",
    index_dir: str = "./index",
    tool_count: int = 20,
    domains: list[str] | None = None,
    n_per_domain: int = 40,
    roles: list[str] | None = None,
    dim: int = 64,
    seed: int = 7,
    workflow_version: str = "v1",
    real_tools: bool = False,
    theme_count: int = 5,
    tools_per_theme: int = 5,
    agents_per_theme: int = 10,
    llm_model: str | None = None,
    llm_base_url: str | None = None,
    llm_api_key: str | None = None,
    tool_output_dir: str | None = None,
    plan_themes: bool = False,
) -> dict:
    domains = domains or list(DEFAULT_DOMAINS)
    roles = roles or ["planner", "researcher", "builder", "checker"]

    if os.path.exists(db_path):
        os.remove(db_path)

    with SQLiteRegistry(db_path) as registry:
        if real_tools:
            llm = LLMClient(api_key=llm_api_key, base_url=llm_base_url, model=llm_model)
            if plan_themes:
                themes = plan_agent_themes(task_text, theme_count, llm)
                if not themes:
                    raise ValueError("No themes generated. Check LLM config or prompt.")
            else:
                themes = themes_from_domains(domains)
            tools_by_theme: dict[str, list[str]] = {}
            for theme in themes:
                planning_text = task_text if plan_themes else ""
                specs = plan_tools_for_theme(planning_text, theme, tools_per_theme, llm)
                tool_ids: list[str] = []
                for spec in specs:
                    code = generate_tool_code(spec, llm)
                    card = register_tool_from_spec(
                        registry,
                        spec,
                        code,
                        save_dir=tool_output_dir,
                    )
                    tool_ids.append(card.id)
                if tool_ids:
                    theme_id = str(theme.get("id") or theme.get("name") or "")
                    tools_by_theme[theme_id] = tool_ids
            generate_agents_from_themes(
                themes=themes,
                n_per_theme=agents_per_theme,
                roles=roles,
                registry=registry,
                tools_by_theme=tools_by_theme,
            )
        else:
            for i in range(tool_count):
                tool_name = "text_cleaner" if i % 2 == 0 else "basic_stats"
                register_tool(registry, tool_name, tool_id=f"{tool_name}-{i}")
            generate_agents(domains=domains, n_per_domain=n_per_domain, roles=roles, registry=registry)

    index = build_index(db_path=db_path, kind="agent", out_dir=index_dir, dim=dim, seed=seed)
    embedder = DummyEmbedder(dim=dim, seed=seed)

    registry = SQLiteRegistry(db_path)
    try:
        result = run_workflow(
            task_text=task_text,
            roles=roles,
            constraints_per_role={},
            workflow_version=workflow_version,
            registry=registry,
            index=index,
            embedder=embedder,
            top_n=10,
            top_k=5,
            mmr_lambda=0.5,
        )
    finally:
        registry.close()

    return result


def _parse_list(value: str) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate tools/agents + run demo workflow")
    parser.add_argument("--task_text", type=str, default="Summarize quarterly performance and risks")
    parser.add_argument("--db", type=str, default="demo_registry.sqlite")
    parser.add_argument("--index_dir", type=str, default="./index")
    parser.add_argument("--tool_count", type=int, default=20)
    parser.add_argument("--domains", type=str, default="")
    parser.add_argument("--n_per_domain", type=int, default=40)
    parser.add_argument("--roles", type=str, default="planner,researcher,builder,checker")
    parser.add_argument("--dim", type=int, default=64)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--workflow_version", type=str, default="v1")
    parser.add_argument("--real_tools", action="store_true")
    parser.add_argument("--theme_count", type=int, default=5)
    parser.add_argument("--tools_per_theme", type=int, default=5)
    parser.add_argument("--agents_per_theme", type=int, default=10)
    parser.add_argument("--llm_model", type=str, default=None)
    parser.add_argument("--llm_base_url", type=str, default=None)
    parser.add_argument("--llm_api_key", type=str, default=None)
    parser.add_argument("--tool_output_dir", type=str, default=None)
    parser.add_argument("--plan_themes", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    result = run_demo(
        task_text=args.task_text,
        db_path=args.db,
        index_dir=args.index_dir,
        tool_count=args.tool_count,
        domains=_parse_list(args.domains) or None,
        n_per_domain=args.n_per_domain,
        roles=_parse_list(args.roles) or None,
        dim=args.dim,
        seed=args.seed,
        workflow_version=args.workflow_version,
        real_tools=args.real_tools,
        theme_count=args.theme_count,
        tools_per_theme=args.tools_per_theme,
        agents_per_theme=args.agents_per_theme,
        llm_model=args.llm_model,
        llm_base_url=args.llm_base_url,
        llm_api_key=args.llm_api_key,
        tool_output_dir=args.tool_output_dir,
        plan_themes=args.plan_themes,
    )
    print(result.get("answer"))
    print(f"log_path: {result.get('log_path')}")


if __name__ == "__main__":
    main()
