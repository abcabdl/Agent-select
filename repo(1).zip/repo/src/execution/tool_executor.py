﻿from __future__ import annotations

from typing import Dict

from core.registry import SQLiteRegistry
from execution.sandbox import execute_tool_code


class ToolExecutor:
    """Execute tool code retrieved from the registry."""

    def __init__(self, registry: SQLiteRegistry, timeout_s: float = 1.0):
        self.registry = registry
        self.timeout_s = timeout_s

    def run_tool(self, tool_id: str, inputs: dict) -> Dict:
        card = self.registry.get(tool_id)
        if card is None:
            return {
                "ok": False,
                "output": None,
                "error": {"code": "tool_not_found", "message": f"Missing tool: {tool_id}"},
            }
        if getattr(card, "kind", None) != "tool":
            return {
                "ok": False,
                "output": None,
                "error": {"code": "not_a_tool", "message": f"Card is not a tool: {tool_id}"},
            }

        code = getattr(card, "code", None)
        if not code:
            code = self.registry.get_tool_code(tool_id)
        if not code:
            return {
                "ok": False,
                "output": None,
                "error": {"code": "tool_code_missing", "message": f"No code for tool: {tool_id}"},
            }

        result = execute_tool_code(code, inputs, timeout_s=self.timeout_s)
        if result.get("ok"):
            return {
                "ok": True,
                "output": result.get("output"),
                "error": None,
            }
        return {
            "ok": False,
            "output": None,
            "error": result.get("error") or {"code": "sandbox_error", "message": "Unknown error"},
        }
